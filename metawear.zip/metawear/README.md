# MetaWear Android App #

This app provides examples of how to use the MetaWear API and a simple app for interacting with the MetaWear board.  For more information about the MetaWear platform, check out our website at [https://mbientlab.com](https://mbientlab.com).

## Build ##
The API was built in Android Studio 2.3.3. It is targeted for Android N (SDK 25) with Android 4.3 (SDK 18) as the minimum required SDK, and requires a JDK compiler compliance level of 1.8.
